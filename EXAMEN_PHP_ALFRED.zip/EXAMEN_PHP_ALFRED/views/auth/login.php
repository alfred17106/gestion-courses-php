<?php
// views/auth/login.php

// Si l'utilisateur est déjà connecté, on le renvoie vers l'admin direct
if (isset($_SESSION['user_id'])) {
    header('Location: /?page=admin_events');
    exit;
}

// TRAITEMENT DU FORMULAIRE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // 1. On cherche l'utilisateur dans la base
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // 2. On vérifie le mot de passe (hashé)
    if ($user && password_verify($password, $user['password'])) {
        // C'est bon ! On connecte la personne
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        
        $_SESSION['flash'] = ['type' => 'success', 'message' => "Connexion réussie. Bienvenue Admin !"];
        header('Location: /?page=admin_events'); // Direction le tableau de bord
        exit;
    } else {
        // C'est pas bon
        $error = "Identifiants incorrects.";
    }
}
?>

<div class="flex items-center justify-center min-h-[60vh]">
    <div class="card w-96 bg-base-100 shadow-xl border border-base-200">
        <div class="card-body">
            <h2 class="card-title justify-center text-2xl mb-4">
                <i class="ph ph-lock-key"></i> Accès Admin
            </h2>

            <?php if (isset($error)): ?>
                <div role="alert" class="alert alert-error text-sm py-2 mb-4">
                    <i class="ph ph-warning-circle"></i>
                    <span><?= $error ?></span>
                </div>
            <?php endif; ?>

            <form action="" method="POST" class="space-y-4">
                <div class="form-control">
                    <label class="label"><span class="label-text">Email</span></label>
                    <input type="email" name="email" placeholder="admin@test.com" 
                           class="input input-bordered" required />
                </div>
                
                <div class="form-control">
                    <label class="label"><span class="label-text">Mot de passe</span></label>
                    <input type="password" name="password" placeholder="••••••" 
                           class="input input-bordered" required />
                </div>

                <div class="form-control mt-6">
                    <button type="submit" class="btn btn-primary">Se connecter</button>
                </div>
            </form>
            
            <div class="text-center mt-4">
                <a href="/" class="link link-hover text-sm text-gray-500">Retour au site public</a>
            </div>
        </div>
    </div>
</div>