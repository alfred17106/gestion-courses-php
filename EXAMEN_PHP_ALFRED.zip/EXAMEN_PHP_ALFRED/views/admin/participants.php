<?php
// views/admin/participants.php

// 1. SÉCURITÉ : On vérifie qu'on a bien un ID d'événement
if (!isset($_GET['id'])) { header('Location: /?page=admin_events'); exit; }
$event_id = $_GET['id'];

// On récupère le terme de recherche (si envoyé par HTMX via la barre de recherche)
$q = $_GET['q'] ?? '';

// On récupère les infos de l'événement (pour afficher son nom en haut)
$stmt = $pdo->prepare("SELECT * FROM events WHERE id = ?");
$stmt->execute([$event_id]);
$event = $stmt->fetch();

// ---------------------------------------------------------
// 2. EXPORT EXCEL (CSV) - LE BONUS "50 BALLES"
// ---------------------------------------------------------
if (isset($_GET['export'])) {
    // On force le navigateur à télécharger un fichier au lieu d'afficher la page
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="liste_inscrits.csv"');
    
    // On ouvre la "sortie" PHP pour écrire dedans
    $output = fopen('php://output', 'w');
    
    // 1. On écrit les titres des colonnes
    fputcsv($output, ['ID', 'Nom', 'Prenom', 'Categorie', 'Dossard', 'Statut']);
    
    // 2. On récupère TOUS les participants de l'événement
    $sql = "SELECT p.*, c.nom as cat_nom FROM participants p 
            LEFT JOIN categories c ON p.category_id = c.id 
            WHERE p.event_id = ?";
    $rows = $pdo->prepare($sql);
    $rows->execute([$event_id]);
    
    // 3. On boucle pour écrire chaque ligne dans le fichier
    while ($row = $rows->fetch()) {
        fputcsv($output, [
            $row['id'], 
            $row['nom'], 
            $row['prenom'], 
            $row['cat_nom'], 
            $row['dossard'] ?? 'Non attribué',
            $row['paiement_ok'] ? 'Payé' : 'Non payé'
        ]);
    }
    fclose($output);
    exit; // IMPORTANT : On arrête tout ici pour ne pas inclure le HTML dans le fichier Excel
}

// ---------------------------------------------------------
// 3. REQUÊTE POUR L'AFFICHAGE (Compatible HTMX)
// ---------------------------------------------------------
$sql = "SELECT p.*, c.nom as cat_nom 
        FROM participants p 
        LEFT JOIN categories c ON p.category_id = c.id 
        WHERE p.event_id = :event_id 
        AND (p.nom LIKE :q OR p.prenom LIKE :q OR p.dossard LIKE :q)
        ORDER BY p.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    'event_id' => $event_id,
    'q' => "%$q%" // Le % permet de chercher "avant" et "après" le texte
]);
$participants = $stmt->fetchAll();
?>

<div class="max-w-6xl mx-auto">
    
    <div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        
        <div class="flex items-center gap-4 w-full md:w-auto">
            <a href="/?page=admin_events" class="btn btn-circle btn-ghost" title="Retour">
                <i class="ph ph-arrow-left text-xl"></i>
            </a>
            <div>
                <h2 class="text-3xl font-bold">Participants</h2>
                <div class="badge badge-primary badge-outline mt-1">
                    <?= htmlspecialchars($event['nom']) ?>
                </div>
            </div>
        </div>

        <div class="flex gap-2 w-full md:w-auto">
            
            <input type="search" 
                   name="q" 
                   value="<?= htmlspecialchars($q) ?>"
                   class="input input-bordered w-full md:w-64" 
                   placeholder="Rechercher nom, dossard..." 
                   hx-get="/?page=admin_participants&id=<?= $event_id ?>"
                   hx-trigger="keyup changed delay:500ms, search"
                   hx-target="#tableau_results"
                   hx-select="#tableau_results"
                   hx-push-url="true"
            />

            <a href="/?page=admin_participants&id=<?= $event_id ?>&export=true" 
               class="btn btn-success text-white" 
               title="Télécharger en CSV">
                <i class="ph ph-file-csv text-xl"></i> Export
            </a>
        </div>
    </div>

    <div class="card bg-base-100 shadow-xl">
        <div class="card-body p-0">
            
            <div id="tableau_results" class="overflow-x-auto">
                <table class="table table-zebra w-full">
                    <thead class="bg-base-200">
                        <tr>
                            <th>Dossard</th>
                            <th>Identité</th>
                            <th>Catégorie</th>
                            <th>Statut</th>
                            <th class="text-right">Gérer</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($participants as $p): ?>
                        <tr>
                            <td>
                                <?php if($p['dossard']): ?>
                                    <span class="badge badge-neutral font-mono font-bold text-lg">#<?= $p['dossard'] ?></span>
                                <?php else: ?>
                                    <span class="text-gray-300 italic text-xs">--</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <div class="font-bold">
                                    <?= htmlspecialchars($p['nom'] . ' ' . $p['prenom']) ?>
                                </div>
                                <div class="text-xs opacity-50">
                                    <?= htmlspecialchars($p['nationalite']) ?> • <?= date('d/m/Y', strtotime($p['date_naissance'])) ?>
                                </div>
                            </td>

                            <td>
                                <div class="badge badge-sm badge-outline">
                                    <?= htmlspecialchars($p['cat_nom']) ?>
                                </div>
                            </td>

                            <td>
                                <?php if($p['non_partant']): ?>
                                    <span class="badge badge-error gap-1 text-white">Forfait</span>
                                <?php elseif($p['paiement_ok']): ?>
                                    <span class="badge badge-success gap-1 text-white">Payé</span>
                                <?php else: ?>
                                    <span class="badge badge-warning gap-1 text-white">En attente</span>
                                <?php endif; ?>
                            </td>

                            <td class="text-right">
                                <a href="/?page=admin_participant_edit&id=<?= $p['id'] ?>" 
                                   class="btn btn-sm btn-ghost btn-square text-info"
                                   title="Modifier dossard/paiement">
                                    <i class="ph ph-pencil-simple text-lg"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        
                        <?php if(empty($participants)): ?>
                            <tr>
                                <td colspan="5" class="text-center py-10 text-gray-400">
                                    <i class="ph ph-magnifying-glass text-3xl mb-2"></i><br>
                                    Aucun participant trouvé.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>