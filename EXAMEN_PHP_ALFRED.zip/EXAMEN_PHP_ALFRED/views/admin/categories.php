<?php
// views/admin/categories.php

// 1. SÉCURITÉ : On doit savoir pour quel événement on travaille
if (!isset($_GET['id'])) { header('Location: /?page=admin_events'); exit; }
$event_id = $_GET['id'];

// On récupère les infos de l'événement (juste pour le titre)
$stmt = $pdo->prepare("SELECT * FROM events WHERE id = ?");
$stmt->execute([$event_id]);
$event = $stmt->fetch();

// 2. SUPPRESSION
if (isset($_GET['delete'])) {
    $cat_id = $_GET['delete'];
    // Vérif si utilisé
    $check = $pdo->prepare("SELECT COUNT(*) FROM participants WHERE category_id = ?");
    $check->execute([$cat_id]);
    
    if ($check->fetchColumn() > 0) {
        $_SESSION['flash'] = ['type' => 'error', 'message' => "Impossible : Il y a des inscrits dans cette catégorie !"];
    } else {
        $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$cat_id]);
        $_SESSION['flash'] = ['type' => 'success', 'message' => "Catégorie supprimée."];
    }
    header("Location: /?page=admin_categories&id=$event_id");
    exit;
}

// 3. AJOUT
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom']);
    if (!empty($nom)) {
        $stmt = $pdo->prepare("INSERT INTO categories (event_id, nom) VALUES (?, ?)");
        $stmt->execute([$event_id, $nom]);
        $_SESSION['flash'] = ['type' => 'success', 'message' => "Catégorie ajoutée !"];
        header("Location: /?page=admin_categories&id=$event_id");
        exit;
    }
}

// 4. LISTE DES CATÉGORIES (De cet événement seulement !)
$stmt = $pdo->prepare("SELECT * FROM categories WHERE event_id = ? ORDER BY id DESC");
$stmt->execute([$event_id]);
$categories = $stmt->fetchAll();
?>

<div class="max-w-4xl mx-auto">
    
    <div class="flex items-center gap-4 mb-6">
        <a href="/?page=admin_events" class="btn btn-circle btn-ghost"><i class="ph ph-arrow-left text-xl"></i></a>
        <div>
            <h2 class="text-3xl font-bold">Catégories</h2>
            <p class="text-gray-500">Pour l'événement : <span class="text-primary font-bold"><?= htmlspecialchars($event['nom']) ?></span></p>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        <div class="card bg-base-100 shadow-xl">
            <div class="card-body">
                <h3 class="card-title text-sm uppercase text-gray-400">Existantes</h3>
                <table class="table table-zebra">
                    <tbody>
    <?php foreach($categories as $cat): ?>
    <tr>
        <td class="font-bold"><?= htmlspecialchars($cat['nom']) ?></td>
        <td class="text-right flex justify-end gap-2">
            <a href="/?page=admin_categories&id=<?= $event_id ?>&edit=<?= $cat['id'] ?>" 
               class="btn btn-xs btn-square btn-ghost text-info"
               title="Modifier">
                <i class="ph ph-pencil-simple"></i>
            </a>
            
            <a href="/?page=admin_categories&id=<?= $event_id ?>&delete=<?= $cat['id'] ?>" 
               class="btn btn-xs btn-square btn-ghost text-error"
               onclick="return confirm('Supprimer ?')">
                <i class="ph ph-trash"></i>
            </a>
        </td>
    </tr>
    <?php endforeach; ?>
    <?php if(empty($categories)): ?>
        <tr><td colspan="2" class="text-gray-400 italic text-center">Aucune catégorie définie.</td></tr>
    <?php endif; ?>
</tbody>
                </table>
            </div>
        </div>

        <div class="card bg-base-100 shadow-xl h-fit border-t-4 border-secondary">
            <div class="card-body">
                <h3 class="card-title">Ajouter une catégorie</h3>
                <p class="text-xs text-gray-500 mb-4">Ex: "10km", "Junior", "Vague 1"...</p>
                
                <form action="" method="POST" class="flex gap-2">
                    <input type="text" name="nom" placeholder="Nom de la catégorie" class="input input-bordered w-full" required />
                    <button class="btn btn-secondary">OK</button>
                </form>
            </div>
        </div>

    </div>
</div>