<?php
// views/admin/participant_edit.php

// 1. SÉCURITÉ
if (!isset($_GET['id'])) { header('Location: /?page=admin_events'); exit; }
$id = $_GET['id'];

// 2. TRAITEMENT (MISE À JOUR COMPLÈTE)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Champs Admin
    $dossard = !empty($_POST['dossard']) ? $_POST['dossard'] : null;
    $paiement = isset($_POST['paiement_ok']) ? 1 : 0;
    $forfait = isset($_POST['non_partant']) ? 1 : 0;
    
    // Champs Identité (Correction erreurs)
    $nom = trim($_POST['nom']);
    $prenom = trim($_POST['prenom']);
    $date_naissance = $_POST['date_naissance']; // AJOUTÉ
    $genre = $_POST['genre']; // AJOUTÉ
    $nationalite = $_POST['nationalite'];
    $club = $_POST['club'];
    $uci = $_POST['code_uci'];
    $tshirt = $_POST['taille_tshirt'];
    $category_id = $_POST['category_id']; // AJOUTÉ (Si on veut changer de course)
    
    $event_id = $_POST['event_id'];

    // Vérification Doublon Dossard
    $doublon = false;
    if ($dossard !== null) {
        $check = $pdo->prepare("SELECT id FROM participants WHERE event_id = ? AND dossard = ? AND id != ?");
        $check->execute([$event_id, $dossard, $id]);
        if ($check->fetch()) { $doublon = true; }
    }

    if ($doublon) {
        $error = "⛔ Le dossard n°$dossard est déjà pris !";
    } else {
        // SQL UPDATE (Avec tous les champs)
        $sql = "UPDATE participants SET 
                dossard = ?, paiement_ok = ?, non_partant = ?, 
                nom = ?, prenom = ?, date_naissance = ?, genre = ?,
                nationalite = ?, club = ?, code_uci = ?, taille_tshirt = ?, category_id = ?
                WHERE id = ?";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $dossard, $paiement, $forfait, 
            $nom, $prenom, $date_naissance, $genre,
            $nationalite, $club, $uci, $tshirt, $category_id,
            $id
        ]);
        
        $_SESSION['flash'] = ['type' => 'success', 'message' => "Participant mis à jour !"];
        header("Location: /?page=admin_participants&id=$event_id");
        exit;
    }
}

// 3. RÉCUPÉRATION
$sql = "SELECT p.*, c.nom as cat_nom, e.nom as event_nom, e.id as event_id 
        FROM participants p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN events e ON p.event_id = e.id
        WHERE p.id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$p = $stmt->fetch();

if (!$p) die("Introuvable.");

// Récupérer toutes les catégories de l'événement (pour le select)
$cats = $pdo->prepare("SELECT * FROM categories WHERE event_id = ?");
$cats->execute([$p['event_id']]);
$categories_list = $cats->fetchAll();
?>

<div class="max-w-5xl mx-auto">
    
    <a href="/?page=admin_participants&id=<?= $p['event_id'] ?>" class="btn btn-ghost mb-4">
        <i class="ph ph-arrow-left"></i> Retour liste
    </a>

    <?php if(isset($error)): ?>
        <div class="alert alert-error shadow-lg mb-4"><span><?= $error ?></span></div>
    <?php endif; ?>

    <form action="" method="POST">
        <input type="hidden" name="event_id" value="<?= $p['event_id'] ?>">

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <div class="md:col-span-2 card bg-base-100 shadow-xl border border-base-200">
                <div class="card-body">
                    <h3 class="card-title text-sm uppercase text-gray-500 mb-4">
                        <i class="ph ph-user"></i> Identité & Sport
                    </h3>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div class="form-control">
                            <label class="label">Nom</label>
                            <input type="text" name="nom" value="<?= htmlspecialchars($p['nom']) ?>" class="input input-bordered" required />
                        </div>
                        <div class="form-control">
                            <label class="label">Prénom</label>
                            <input type="text" name="prenom" value="<?= htmlspecialchars($p['prenom']) ?>" class="input input-bordered" required />
                        </div>
                        
                        <div class="form-control">
                            <label class="label">Date Naissance</label>
                            <input type="date" name="date_naissance" value="<?= $p['date_naissance'] ?>" class="input input-bordered" required />
                        </div>
                        <div class="form-control">
                            <label class="label">Genre</label>
                            <select name="genre" class="select select-bordered">
                                <option value="Homme" <?= $p['genre'] == 'Homme' ? 'selected' : '' ?>>Homme</option>
                                <option value="Femme" <?= $p['genre'] == 'Femme' ? 'selected' : '' ?>>Femme</option>
                                <option value="Mixte" <?= $p['genre'] == 'Mixte' ? 'selected' : '' ?>>Mixte</option>
                            </select>
                        </div>
                        
                        <div class="form-control col-span-2">
                            <label class="label font-bold text-primary">Catégorie / Course</label>
                            <select name="category_id" class="select select-bordered select-primary">
                                <?php foreach($categories_list as $cat): ?>
                                    <option value="<?= $cat['id'] ?>" <?= $p['category_id'] == $cat['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($cat['nom']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-control">
                            <label class="label">Nationalité</label>
                            <input type="text" name="nationalite" value="<?= htmlspecialchars($p['nationalite']) ?>" class="input input-bordered" />
                        </div>
                        <div class="form-control">
                            <label class="label">Club</label>
                            <input type="text" name="club" value="<?= htmlspecialchars($p['club']) ?>" class="input input-bordered" />
                        </div>
                        <div class="form-control">
                            <label class="label">Code UCI</label>
                            <input type="text" name="code_uci" value="<?= htmlspecialchars($p['code_uci'] ?? '') ?>" class="input input-bordered" />
                        </div>
                        <div class="form-control">
                            <label class="label">Taille T-Shirt</label>
                            <select name="taille_tshirt" class="select select-bordered">
                                <option value="" <?= empty($p['taille_tshirt']) ? 'selected' : '' ?>>-- Pas de T-shirt --</option>
                                
                                <option value="XS" <?= $p['taille_tshirt'] === 'XS' ? 'selected' : '' ?>>XS</option>
                                <option value="S"  <?= $p['taille_tshirt'] === 'S'  ? 'selected' : '' ?>>S - Small</option>
                                <option value="M"  <?= $p['taille_tshirt'] === 'M'  ? 'selected' : '' ?>>M - Medium</option>
                                <option value="L"  <?= $p['taille_tshirt'] === 'L'  ? 'selected' : '' ?>>L - Large</option>
                                <option value="XL" <?= $p['taille_tshirt'] === 'XL' ? 'selected' : '' ?>>XL - Extra Large</option>
                            </select>
                        </div>
                        
                    </div>
                </div>
            </div>

            <div class="card bg-base-100 shadow-xl border-t-8 border-primary h-fit">
                <div class="card-body bg-primary/5">
                    <h3 class="card-title text-primary mb-4">
                        <i class="ph ph-gear"></i> Dossard & Paiement
                    </h3>

                    <div class="form-control mb-6">
                        <label class="label font-bold text-lg">Dossard N°</label>
                        <input type="number" name="dossard" 
                               value="<?= $p['dossard'] ?>" 
                               placeholder="---" 
                               class="input input-lg input-primary w-full text-center text-3xl font-mono font-bold" />
                    </div>

                    <div class="form-control mb-2">
                        <label class="label cursor-pointer justify-start gap-3">
                            <input type="checkbox" name="paiement_ok" class="checkbox checkbox-success" 
                                   <?= $p['paiement_ok'] ? 'checked' : '' ?> />
                            <span class="label-text font-bold text-success">Paiement OK</span>
                        </label>
                    </div>

                    <div class="form-control">
                        <label class="label cursor-pointer justify-start gap-3">
                            <input type="checkbox" name="non_partant" class="checkbox checkbox-error" 
                                   <?= $p['non_partant'] ? 'checked' : '' ?> />
                            <span class="label-text font-bold text-error">Non-Partant </span>
                        </label>
                    </div>

                    <button type="submit" class="btn btn-primary w-full mt-6 shadow-lg">
                        <i class="ph ph-floppy-disk"></i> Enregistrer Tout
                    </button>
                </div>
            </div>

        </div>
    </form>
</div>