<?php
// views/admin/events.php

// 1. SUPPRESSION
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM events WHERE id = ?");
    $stmt->execute([$id]);
    $_SESSION['flash'] = ['type' => 'success', 'message' => "Événement supprimé."];
    header('Location: /?page=admin_events');
    exit;
}

// 2. PRÉPARATION MODE ÉDITION
$mode_edition = false;
$event_to_edit = ['id' => '', 'nom' => '', 'date_event' => '', 'description' => ''];

if (isset($_GET['edit_event'])) {
    $mode_edition = true;
    $stmt = $pdo->prepare("SELECT * FROM events WHERE id = ?");
    $stmt->execute([$_GET['edit_event']]);
    $event_to_edit = $stmt->fetch();
}

// 3. TRAITEMENT DU FORMULAIRE (Création OU Modification)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom']);
    $desc = trim($_POST['description']);
    $date = $_POST['date_event'];
    $id_modif = $_POST['event_id'] ?? null;

    if (!empty($nom) && !empty($date)) {
        if ($id_modif) {
            // UPDATE
            $stmt = $pdo->prepare("UPDATE events SET nom = ?, description = ?, date_event = ? WHERE id = ?");
            $stmt->execute([$nom, $desc, $date, $id_modif]);
            $msg = "Événement modifié avec succès !";
        } else {
            // INSERT
            $stmt = $pdo->prepare("INSERT INTO events (nom, description, date_event) VALUES (?, ?, ?)");
            $stmt->execute([$nom, $desc, $date]);
            $msg = "Événement créé !";
        }
        
        $_SESSION['flash'] = ['type' => 'success', 'message' => $msg];
        header('Location: /?page=admin_events');
        exit;
    }
}

// 4. LISTE
$events = $pdo->query("
    SELECT e.*, 
    (SELECT COUNT(*) FROM participants p WHERE p.event_id = e.id) as total_inscrits,
    (SELECT COUNT(*) FROM categories c WHERE c.event_id = e.id) as total_categories
    FROM events e 
    ORDER BY date_event DESC
")->fetchAll();
?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

    <div class="lg:col-span-2">
        <div class="card bg-base-100 shadow-xl">
            <div class="card-body">
                <h2 class="card-title text-2xl mb-4"><i class="ph ph-kanban text-primary"></i> Gestion des Événements</h2>

                <div class="overflow-x-auto">
                    <table class="table table-zebra">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Événement</th>
                                <th class="text-center">Infos</th>
                                <th class="text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($events as $event): ?>
                            <tr class="hover">
                                <td class="whitespace-nowrap font-mono text-sm">
                                    <?= date('d/m/Y', strtotime($event['date_event'])) ?>
                                </td>
                                <td>
                                    <div class="font-bold text-lg"><?= htmlspecialchars($event['nom']) ?></div>
                                    <div class="text-xs text-gray-500 truncate max-w-xs">
                                        <?= htmlspecialchars($event['description']) ?>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <div class="badge badge-primary badge-outline gap-1">
                                        <i class="ph ph-users"></i> <?= $event['total_inscrits'] ?>
                                    </div>
                                    <div class="badge badge-secondary badge-outline gap-1">
                                        <i class="ph ph-list-dashes"></i> <?= $event['total_categories'] ?>
                                    </div>
                                </td>
                                <td class="text-right flex flex-col gap-2 items-end">
                                    <div class="flex gap-1">
                                        <a href="/?page=admin_events&edit_event=<?= $event['id'] ?>" class="btn btn-xs btn-square btn-ghost text-info" title="Modifier infos">
                                            <i class="ph ph-pencil-simple"></i>
                                        </a>
                                        <a href="/?page=admin_events&delete=<?= $event['id'] ?>" 
                                           onclick="return confirm('Supprimer cet événement et tous ses inscrits ?')"
                                           class="btn btn-xs btn-square btn-ghost text-error">
                                            <i class="ph ph-trash"></i>
                                        </a>
                                    </div>
                                    
                                    <a href="/?page=admin_categories&id=<?= $event['id'] ?>" class="btn btn-xs btn-secondary w-full">
                                        Catégories
                                    </a>
                                    <a href="/?page=admin_participants&id=<?= $event['id'] ?>" class="btn btn-xs btn-primary w-full">
                                        Inscrits
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div>
        <div class="card bg-base-100 shadow-xl border-t-4 <?= $mode_edition ? 'border-info' : 'border-success' ?> sticky top-4">
            <div class="card-body">
                <h2 class="card-title <?= $mode_edition ? 'text-info' : 'text-success' ?>">
                    <i class="ph <?= $mode_edition ? 'ph-pencil' : 'ph-plus-circle' ?>"></i> 
                    <?= $mode_edition ? 'Modifier' : 'Nouveau' ?>
                </h2>
                
                <form action="" method="POST" class="flex flex-col gap-3">
                    <?php if($mode_edition): ?>
                        <input type="hidden" name="event_id" value="<?= $event_to_edit['id'] ?>">
                    <?php endif; ?>

                    <div class="form-control">
                        <label class="label text-xs font-bold">Nom de l'événement</label>
                        <input type="text" name="nom" 
                               value="<?= htmlspecialchars($event_to_edit['nom']) ?>"
                               class="input input-bordered w-full" required />
                    </div>
                    
                    <div class="form-control">
                        <label class="label text-xs font-bold">Date</label>
                        <input type="date" name="date_event" 
                               value="<?= $event_to_edit['date_event'] ?>"
                               class="input input-bordered w-full" required />
                    </div>

                    <div class="form-control">
                        <label class="label text-xs font-bold">Description</label>
                        <textarea name="description" class="textarea textarea-bordered h-20"><?= htmlspecialchars($event_to_edit['description']) ?></textarea>
                    </div>

                    <div class="flex gap-2 mt-4">
                        <?php if($mode_edition): ?>
                            <a href="/?page=admin_events" class="btn btn-ghost flex-1">Annuler</a>
                        <?php endif; ?>
                        <button type="submit" class="btn <?= $mode_edition ? 'btn-info' : 'btn-success text-white' ?> flex-1">
                            <?= $mode_edition ? 'Enregistrer' : 'Créer' ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>