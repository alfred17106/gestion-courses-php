<!DOCTYPE html>
<html lang="fr" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Événements Sportifs</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.4.19/dist/full.min.css" rel="stylesheet" type="text/css" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/htmx.org@1.9.10" integrity="sha384-D1Kt99CQMDuVetoL1lrYwg5t+9QdHe7NLX/SoJYkXDFfX37iInKRy5xLSi8nO7UC" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">

    <div class="navbar bg-white shadow-sm mb-8">
        <div class="container mx-auto">
            <div class="flex-1">
                <a href="/" class="btn btn-ghost text-xl font-bold text-blue-600">
                    <i class="ph ph-trophy"></i> Alfredo-Chrono-Race
                </a>
            </div>
            <div class="flex-none">
                <ul class="menu menu-horizontal px-1">
                    <li><a href="/">Accueil</a></li>
                    
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <li><a href="/?page=admin_events">Gérer Événements</a></li>
                        <li><a href="/logout.php" class="text-error">Déconnexion</a></li>
                    <?php else: ?>
                        <li><a href="/?page=login" class="btn btn-sm btn-ghost">Admin</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>

    <main class="flex-grow container mx-auto px-4">
        <?php if (isset($_SESSION['flash'])): ?>
            <div role="alert" class="alert alert-<?= $_SESSION['flash']['type'] ?> mb-6 shadow-md">
                <span><?= $_SESSION['flash']['message'] ?></span>
            </div>
            <?php unset($_SESSION['flash']); ?>
        <?php endif; ?>

        <?= $content ?? '' ?>
    </main>

    <footer class="footer footer-center p-4 bg-gray-200 text-base-content mt-10">
        <aside>
            <p>Copyright © 2025 - Examen PHP Alfred</p>
        </aside>
    </footer>
    <script>
        // On attend 4 secondes (4000 ms)
        setTimeout(function() {
            // On sélectionne tous les éléments qui ont la classe "alert"
            const alerts = document.querySelectorAll('.alert');
            
            alerts.forEach(function(alert) {
                // On ajoute une transition pour que ça soit joli
                alert.style.transition = "opacity 0.5s ease";
                alert.style.opacity = "0"; // On le rend transparent
                
                // Après la transition (0.5s), on le supprime du HTML
                setTimeout(function() {
                    alert.remove();
                }, 500);
            });
        }, 4000);
    </script>

</body>
</html>

</body>
</html>