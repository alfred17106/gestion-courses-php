<?php
// views/public/home.php

// 1. On récupère les événements actifs depuis la BDD
$events = $pdo->query("SELECT * FROM events ORDER BY date_event ASC")->fetchAll();
?>

<div class="text-center mb-10">
    <h1 class="text-4xl font-bold text-gray-800">Inscriptions aux événements</h1>
    <p class="py-4 text-gray-500">Choisissez une course ci-dessous pour vous inscrire.</p>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
    
    <?php foreach($events as $event): ?>
        <div class="card bg-white shadow-xl hover:shadow-2xl transition-all border border-blue-100">
            <div class="card-body items-center text-center">
                
                <div class="w-16 h-16 rounded-2xl bg-blue-600 flex items-center justify-center text-white mb-4 shadow-lg shadow-blue-200">
                    <i class="ph ph-lightning text-3xl"></i>
                </div>

                <h2 class="card-title text-2xl mb-1"><?= htmlspecialchars($event['nom']) ?></h2>
                <div class="badge badge-ghost mb-4"><?= date('d/m/Y', strtotime($event['date_event'])) ?></div>
                
                <p class="text-gray-500 mb-6"><?= htmlspecialchars($event['description']) ?></p>
                
                <div class="card-actions w-full">
                    <a href="/?page=inscription&event_id=<?= $event['id'] ?>" class="btn btn-primary w-full text-lg">
                        S'inscrire
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; ?>

</div>