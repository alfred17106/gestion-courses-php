<?php
// views/public/inscription.php

// 1. VÉRIFICATION : A-t-on un ID d'événement ?
if (!isset($_GET['event_id'])) {
    header('Location: /'); // Sinon retour accueil
    exit;
}
$event_id = $_GET['event_id'];

// 2. RÉCUPÉRATION DES INFOS DE L'ÉVÉNEMENT
$stmt = $pdo->prepare("SELECT * FROM events WHERE id = ?");
$stmt->execute([$event_id]);
$event = $stmt->fetch();

if (!$event) { die("Événement introuvable."); }

// 3. RÉCUPÉRATION DES CATÉGORIES (Uniquement pour CET événement)
$stmt = $pdo->prepare("SELECT * FROM categories WHERE event_id = ?");
$stmt->execute([$event_id]);
$categories = $stmt->fetchAll();

// 4. LISTE DES PAYS (Pour le menu déroulant)
$tous_les_pays = [
    "Afghanistan"=>"🇦🇫 Afghanistan", "Afrique du Sud"=>"🇿🇦 Afrique du Sud", "Albanie"=>"🇦🇱 Albanie", "Algérie"=>"🇩🇿 Algérie", "Allemagne"=>"🇩🇪 Allemagne", "Andorre"=>"🇦🇩 Andorre", "Angola"=>"🇦🇴 Angola", "Arabie saoudite"=>"🇸🇦 Arabie saoudite", "Argentine"=>"🇦🇷 Argentine", "Arménie"=>"🇦🇲 Arménie", "Australie"=>"🇦🇺 Australie", "Autriche"=>"🇦🇹 Autriche", "Azerbaïdjan"=>"🇦🇿 Azerbaïdjan", "Bahamas"=>"🇧🇸 Bahamas", "Bahreïn"=>"🇧🇭 Bahreïn", "Bangladesh"=>"🇧🇩 Bangladesh", "Barbade"=>"🇧🇧 Barbade", "Belgique"=>"🇧🇪 Belgique", "Belize"=>"🇧🇿 Belize", "Bénin"=>"🇧🇯 Bénin", "Bhoutan"=>"🇧🇹 Bhoutan", "Biélorussie"=>"🇧🇾 Biélorussie", "Birmanie"=>"🇲🇲 Birmanie", "Bolivie"=>"🇧🇴 Bolivie", "Bosnie-Herzégovine"=>"🇧🇦 Bosnie-Herzégovine", "Botswana"=>"🇧🇼 Botswana", "Brésil"=>"🇧🇷 Brésil", "Brunei"=>"🇧🇳 Brunei", "Bulgarie"=>"🇧🇬 Bulgarie", "Burkina Faso"=>"🇧🇫 Burkina Faso", "Burundi"=>"🇧🇮 Burundi", "Cambodge"=>"🇰🇭 Cambodge", "Cameroun"=>"🇨🇲 Cameroun", "Canada"=>"🇨🇦 Canada", "Cap-Vert"=>"🇨🇻 Cap-Vert", "Centrafrique"=>"🇨🇫 Centrafrique", "Chili"=>"🇨🇱 Chili", "Chine"=>"🇨🇳 Chine", "Chypre"=>"🇨🇾 Chypre", "Colombie"=>"🇨🇴 Colombie", "Comores"=>"🇰🇲 Comores", "Congo-Brazzaville"=>"🇨🇬 Congo", "Congo-Kinshasa"=>"🇨🇩 RDC", "Corée du Nord"=>"🇰🇵 Corée du Nord", "Corée du Sud"=>"🇰🇷 Corée du Sud", "Costa Rica"=>"🇨🇷 Costa Rica", "Côte d'Ivoire"=>"🇨🇮 Côte d'Ivoire", "Croatie"=>"🇭🇷 Croatie", "Cuba"=>"🇨🇺 Cuba", "Danemark"=>"🇩🇰 Danemark", "Djibouti"=>"🇩🇯 Djibouti", "Dominique"=>"🇩🇲 Dominique", "Égypte"=>"🇪🇬 Égypte", "Émirats arabes unis"=>"🇦🇪 EAU", "Équateur"=>"🇪🇨 Équateur", "Érythrée"=>"🇪🇷 Érythrée", "Espagne"=>"🇪🇸 Espagne", "Estonie"=>"🇪🇪 Estonie", "États-Unis"=>"🇺🇸 États-Unis", "Éthiopie"=>"🇪🇹 Éthiopie", "Fidji"=>"🇫🇯 Fidji", "Finlande"=>"🇫🇮 Finlande", "France"=>"🇫🇷 France", "Gabon"=>"🇬🇦 Gabon", "Gambie"=>"🇬🇲 Gambie", "Géorgie"=>"🇬🇪 Géorgie", "Ghana"=>"🇬🇭 Ghana", "Grèce"=>"🇬🇷 Grèce", "Grenade"=>"🇬🇩 Grenade", "Guatemala"=>"🇬🇹 Guatemala", "Guinée"=>"🇬🇳 Guinée", "Guyana"=>"🇬🇾 Guyana", "Haïti"=>"🇭🇹 Haïti", "Honduras"=>"🇭🇳 Honduras", "Hongrie"=>"🇭🇺 Hongrie", "Inde"=>"🇮🇳 Inde", "Indonésie"=>"🇮🇩 Indonésie", "Irak"=>"🇮🇶 Irak", "Iran"=>"🇮🇷 Iran", "Irlande"=>"🇮🇪 Irlande", "Islande"=>"🇮🇸 Islande", "Israël"=>"🇮🇱 Israël", "Italie"=>"🇮🇹 Italie", "Jamaïque"=>"🇯🇲 Jamaïque", "Japon"=>"🇯🇵 Japon", "Jordanie"=>"🇯🇴 Jordanie", "Kazakhstan"=>"🇰🇿 Kazakhstan", "Kenya"=>"🇰🇪 Kenya", "Kirghizistan"=>"🇰🇬 Kirghizistan", "Kiribati"=>"🇰🇮 Kiribati", "Koweït"=>"🇰🇼 Koweït", "Laos"=>"🇱🇦 Laos", "Lesotho"=>"🇱🇸 Lesotho", "Lettonie"=>"🇱🇻 Lettonie", "Liban"=>"🇱🇧 Liban", "Liberia"=>"🇱🇷 Liberia", "Libye"=>"🇱🇾 Libye", "Liechtenstein"=>"🇱🇮 Liechtenstein", "Lituanie"=>"🇱🇹 Lituanie", "Luxembourg"=>"🇱🇺 Luxembourg", "Macédoine du Nord"=>"🇲🇰 Macédoine", "Madagascar"=>"🇲🇬 Madagascar", "Malaisie"=>"🇲🇾 Malaisie", "Malawi"=>"🇲🇼 Malawi", "Maldives"=>"🇲🇻 Maldives", "Mali"=>"🇲🇱 Mali", "Malte"=>"🇲🇹 Malte", "Maroc"=>"🇲🇦 Maroc", "Maurice"=>"🇲🇺 Maurice", "Mauritanie"=>"🇲🇷 Mauritanie", "Mexique"=>"🇲🇽 Mexique", "Micronésie"=>"🇫🇲 Micronésie", "Moldavie"=>"🇲🇩 Moldavie", "Monaco"=>"🇲🇨 Monaco", "Mongolie"=>"🇲🇳 Mongolie", "Monténégro"=>"🇲🇪 Monténégro", "Mozambique"=>"🇲🇿 Mozambique", "Namibie"=>"🇳🇦 Namibie", "Nauru"=>"🇳🇷 Nauru", "Népal"=>"🇳🇵 Népal", "Nicaragua"=>"🇳🇮 Nicaragua", "Niger"=>"🇳🇪 Niger", "Nigeria"=>"🇳🇬 Nigeria", "Norvège"=>"🇳🇴 Norvège", "Nouvelle-Zélande"=>"🇳🇿 N. Zélande", "Oman"=>"🇴🇲 Oman", "Ouganda"=>"🇺🇬 Ouganda", "Ouzbékistan"=>"🇺🇿 Ouzbékistan", "Pakistan"=>"🇵🇰 Pakistan", "Palaos"=>"🇵🇼 Palaos", "Panama"=>"🇵🇦 Panama", "Papouasie-N.G."=>"🇵🇬 Papouasie", "Paraguay"=>"🇵🇾 Paraguay", "Pays-Bas"=>"🇳🇱 Pays-Bas", "Pérou"=>"🇵🇪 Pérou", "Philippines"=>"🇵🇭 Philippines", "Pologne"=>"🇵🇱 Pologne", "Portugal"=>"🇵🇹 Portugal", "Qatar"=>"🇶🇦 Qatar", "Roumanie"=>"🇷🇴 Roumanie", "Royaume-Uni"=>"🇬🇧 Royaume-Uni", "Russie"=>"🇷🇺 Russie", "Rwanda"=>"🇷🇼 Rwanda", "Salvador"=>"🇸🇻 Salvador", "Samoa"=>"🇼🇸 Samoa", "Sénégal"=>"🇸🇳 Sénégal", "Serbie"=>"🇷🇸 Serbie", "Seychelles"=>"🇸🇨 Seychelles", "Sierra Leone"=>"🇸🇱 Sierra Leone", "Singapour"=>"🇸🇬 Singapour", "Slovaquie"=>"🇸🇰 Slovaquie", "Slovénie"=>"🇸🇮 Slovénie", "Somalie"=>"🇸🇴 Somalie", "Soudan"=>"🇸🇩 Soudan", "Sri Lanka"=>"🇱🇰 Sri Lanka", "Suède"=>"🇸🇪 Suède", "Suisse"=>"🇨🇭 Suisse", "Suriname"=>"🇸🇷 Suriname", "Syrie"=>"🇸🇾 Syrie", "Tadjikistan"=>"🇹🇯 Tadjikistan", "Tanzanie"=>"🇹🇿 Tanzanie", "Tchad"=>"🇹🇩 Tchad", "Tchéquie"=>"🇨🇿 Tchéquie", "Thaïlande"=>"🇹🇭 Thaïlande", "Timor oriental"=>"🇹🇱 Timor", "Togo"=>"🇹🇬 Togo", "Tonga"=>"🇹🇴 Tonga", "Trinité-et-Tobago"=>"🇹🇹 Trinité", "Tunisie"=>"🇹🇳 Tunisie", "Turkménistan"=>"🇹🇲 Turkménistan", "Turquie"=>"🇹🇷 Turquie", "Tuvalu"=>"🇹🇻 Tuvalu", "Ukraine"=>"🇺🇦 Ukraine", "Uruguay"=>"🇺🇾 Uruguay", "Vanuatu"=>"🇻🇺 Vanuatu", "Vatican"=>"🇻🇦 Vatican", "Venezuela"=>"🇻🇪 Venezuela", "Viêt Nam"=>"🇻🇳 Viêt Nam", "Yémen"=>"🇾🇪 Yémen", "Zambie"=>"🇿🇲 Zambie", "Zimbabwe"=>"🇿🇼 Zimbabwe", "Autre"=>"🌍 Autre"
];

// 5. TRAITEMENT DU FORMULAIRE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération
    $nom = trim($_POST['nom']);
    $prenom = trim($_POST['prenom']);
    $category_id = $_POST['category_id'];
    $nationalite = $_POST['nationalite'];
    
    // Construction de la date (YYYY-MM-DD) pour la base de données
    $date_naissance = $_POST['annee'] . '-' . str_pad($_POST['mois'], 2, '0', STR_PAD_LEFT) . '-' . str_pad($_POST['jour'], 2, '0', STR_PAD_LEFT);

    $errors = [];

    // Validation
    if (empty($nom) || empty($prenom) || empty($category_id)) {
        $errors[] = "Veuillez remplir tous les champs obligatoires.";
    }

    // Règle Anti-Russie
    if (strpos($nationalite, 'Russie') !== false) {
        $errors[] = "Les inscriptions sont fermées pour cette nationalité.";
    }

    // Enregistrement
    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO participants (
            event_id, category_id, nom, prenom, genre, 
            date_naissance, nationalite, taille_tshirt, club, non_partant
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->execute([
            $event_id, // Important : on lie le participant à l'événement
            $category_id,
            $nom,
            $prenom,
            $_POST['genre'],
            $date_naissance,
            $nationalite,
            $_POST['taille_tshirt'] ?? null,
            $_POST['club'],

            isset($_POST['non_partant']) ? 1 : 0
        ]);

        $_SESSION['flash'] = ['type' => 'success', 'message' => "Inscription validée pour l'événement : " . htmlspecialchars($event['nom'])];
        header('Location: /');
        exit;
    } else {
        $_SESSION['flash'] = ['type' => 'error', 'message' => implode('<br>', $errors)];
    }
}
?>

<div class="max-w-2xl mx-auto py-10">
    
    <div class="text-center mb-8">
        <h2 class="text-2xl font-bold text-gray-700">Inscription</h2>
        <h1 class="text-4xl font-bold text-primary mt-2"><?= htmlspecialchars($event['nom']) ?></h1>
        <p class="text-gray-500 mt-2">Date de l'événement : <?= date('d/m/Y', strtotime($event['date_event'])) ?></p>
    </div>

    <div class="card bg-white shadow-xl border-t-4 border-primary">
        <div class="card-body">
            
            <form action="" method="POST" class="space-y-4">
                
                <div class="form-control">
                    <label class="label font-bold">Catégorie / Course *</label>
                    <select name="category_id" class="select select-bordered w-full" required>
                        <option value="" disabled selected>-- Choisissez votre distance --</option>
                        <?php foreach($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['nom']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="form-control">
                        <label class="label">Nom *</label>
                        <input type="text" name="nom" class="input input-bordered" required />
                    </div>
                    <div class="form-control">
                        <label class="label">Prénom *</label>
                        <input type="text" name="prenom" class="input input-bordered" required />
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="form-control">
                        <label class="label">Genre</label>
                        <select name="genre" class="select select-bordered">
                            <option value="Homme">Homme</option>
                            <option value="Femme">Femme</option>
                            <option value="Mixte">Autre</option>
                        </select>
                    </div>
                    
                    <div class="form-control">
                        <label class="label">Date de Naissance</label>
                        <div class="flex gap-1">
                            <input type="number" name="jour" placeholder="JJ" class="input input-bordered w-1/4" min="1" max="31" required />
                            <input type="number" name="mois" placeholder="MM" class="input input-bordered w-1/4" min="1" max="12" required />
                            <input type="number" name="annee" placeholder="AAAA" class="input input-bordered w-1/2" min="1900" max="2025" required />
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="form-control">
                        <label class="label">Nationalité</label>
                        <select name="nationalite" class="select select-bordered">
                            <?php foreach($tous_les_pays as $nom_simple => $affichage): ?>
                                <?php if ($nom_simple === 'Russie') continue; ?>
                                <option value="<?= $affichage ?>"><?= $affichage ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-control">
                        <label class="label">Club (Optionnel)</label>
                        <input type="text" name="club" class="input input-bordered" />
                    </div>
                </div>

                <div class="flex justify-between items-center mt-8 pt-4 border-t">
                    <a href="/" class="btn btn-ghost">Annuler</a>
                    <div class="form-control">
    <label class="label font-bold">T-shirt souvenir (Optionnel)</label>
    <select name="taille_tshirt" class="select select-bordered w-full">
        <option value="">-- Pas de T-shirt --</option>
        <option value="XS">XS - Extra Small</option>
        <option value="S">S - Small</option>
        <option value="M">M - Medium</option>
        <option value="L">L - Large</option>
        <option value="XL">XL - Extra Large</option>
    </select>
</div>                  
                    <button type="submit" class="btn btn-primary px-8">Valider l'inscription</button>
                </div>

            </form>
        </div>
    </div>
</div>