<?php
// public/install.php
require_once __DIR__ . '/../models/db.php';

try {
    // 1. UTILISATEURS (Admin)
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    )");

    // 2. ÉVÉNEMENTS (La table mère : Ultra Trail, Examen PHP...)
    $pdo->exec("CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom TEXT NOT NULL,
        description TEXT,
        date_event DATE,
        image TEXT -- Pour l'icône ou l'image 
    )");

    // 3. CATÉGORIES (Liées à un événement précis)
    $pdo->exec("CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id INTEGER NOT NULL,
        nom TEXT NOT NULL,
        FOREIGN KEY(event_id) REFERENCES events(id) ON DELETE CASCADE
    )");

    // 4. PARTICIPANTS (Le gros morceau)
    $pdo->exec("CREATE TABLE IF NOT EXISTS participants (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id INTEGER NOT NULL,    -- Il participe à QUEL événement ?
        category_id INTEGER NOT NULL, -- Il est dans QUELLE catégorie ?
        
        -- Infos Identité
        nom TEXT NOT NULL,
        prenom TEXT NOT NULL,
        genre TEXT NOT NULL,
        date_naissance DATE NOT NULL,
        nationalite TEXT,
        club TEXT,
        
        -- Infos en plus
        code_uci TEXT,
        taille_tshirt TEXT,
        
        -- Gestion Course (Admin)
        dossard INTEGER,
        paiement_ok INTEGER DEFAULT 0, -- 0=Non, 1=Oui
        non_partant INTEGER DEFAULT 0, -- 0=Partant, 1=Forfait
        
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        
        -- Sécurités (Clés étrangères)
        FOREIGN KEY(event_id) REFERENCES events(id) ON DELETE CASCADE,
        FOREIGN KEY(category_id) REFERENCES categories(id)
    )");

    // --- REMISE À ZÉRO (Pour être propre) ---
    $pdo->exec("DELETE FROM participants; DELETE FROM categories; DELETE FROM events; DELETE FROM users;");

    // --- DONNÉES DE TEST (Pour que tu voies direct le résultat) ---
    
    // 1. Admin (admin@test.com / admin)
    $mdp = password_hash("admin", PASSWORD_DEFAULT);
    $pdo->exec("INSERT INTO users (email, password) VALUES ('admin@test.com', '$mdp')");

    // 2. Événement 1 : Velo
    $pdo->exec("INSERT INTO events (nom, description, date_event) VALUES ('Grand Peix velo Namur 2025', 'Course velo à Namur', '2025-01-27')");
    $id_esa = $pdo->lastInsertId();
    // Catégories pour Velo
    $pdo->exec("INSERT INTO categories (event_id, nom) VALUES ($id_esa, '30km Expert')");
    $pdo->exec("INSERT INTO categories (event_id, nom) VALUES ($id_esa, '10km Découverte')");

    // 3. Événement 2 : Marathon NAMUR
    $pdo->exec("INSERT INTO events (nom, description, date_event) VALUES ('Marathon NAMUR', 'Course etudiants de Namur', '2026-01-08')");
    $id_php = $pdo->lastInsertId();
    // Catégories pour Marathon NAMUR
    $pdo->exec("INSERT INTO categories (event_id, nom) VALUES ($id_php, 'Full Marathon')");
    $pdo->exec("INSERT INTO categories (event_id, nom) VALUES ($id_php, 'Semi-Marathon')");

    dd("✅ BASE DE DONNÉES INSTALLÉE (Mode Multi-Événements)");

} catch (PDOException $e) {
    dd($e->getMessage());
}