<?php
// public/index.php
session_start();

// Connexion à la BDD (Le fichier qu'on a créé au tout début)
require_once '../models/db.php';

// Quelle page on veut ? (Par défaut : home)
$page = $_GET['page'] ?? 'home';

// On commence à enregistrer l'affichage
ob_start();

switch($page) {
    // --- PARTIE PUBLIQUE ---
    case 'home':
        require '../views/public/home.php'; // On va le créer juste après
        break;

    case 'inscription':
        require '../views/public/inscription.php';
        break;

    case 'login':
        require '../views/auth/login.php';
        break;

    // --- PARTIE ADMIN (PROTÉGÉE) ---
    case 'admin_events':
        if (!isset($_SESSION['user_id'])) { header('Location: /?page=login'); exit; }
        require '../views/admin/events.php';
        break;

    // Gérer les catégories d'un événement spécifique
    case 'admin_categories':
        if (!isset($_SESSION['user_id'])) { header('Location: /?page=login'); exit; }
        require '../views/admin/categories.php';
        break;

    // Voir les inscrits d'un événement spécifique
    case 'admin_participants':
        if (!isset($_SESSION['user_id'])) { header('Location: /?page=login'); exit; }
        require '../views/admin/participants.php';
        break;
        
    // Modifier un participant (Dossard)
    case 'admin_participant_edit':
        if (!isset($_SESSION['user_id'])) { header('Location: /?page=login'); exit; }
        require '../views/admin/participant_edit.php';
        break;

    default:
        echo "<div class='alert alert-error'>Page introuvable (404)</div>";
}

// On récupère tout le contenu et on l'injecte dans le layout
$content = ob_get_clean();
require '../views/layout.php';