<?php
// public/logout.php
session_start();

// On détruit toutes les traces de la connexion
session_destroy();

// On redirige vers la page de login
header('Location: /?page=login');
exit;