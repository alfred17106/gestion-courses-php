<?php
// models/db.php

//1. On charge les outils (le Dumper pour le debug, et la connexion a la BDD)
require_once __DIR__ . '/../vendor/autoload.php';

try{
    //2. On se connecte a la BDD (le fichier database.sqlite qui est à coté)
    $pdo = new PDO('sqlite:'.__DIR__.'/../models/database.sqlite');

    //3. Option pour voir les erreurs SQL dans la console (utile pour le debug)
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

}catch (PDOException $e){
    // Si ca ne marche pas, on affiche l'erreur en joli et on stoppe tout
    dd("Erreur de connexion : ".$e->getMessage());
    die();

}